package com.example.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
public class ColumnDefn {


    private Long id;

    private String col_id;

    private String colName;

    private String datatype;

    private int maxLength;

    private boolean isRelation;

    private String relatedTable;


    public ColumnDefn() {

    }
}