package com.example.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
public class CustomObjectDefn {


    private Long id;

    private String name;

    private String api_path;

    private String cols_link_id;

    public CustomObjectDefn() {

    }
}