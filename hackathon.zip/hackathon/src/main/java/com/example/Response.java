package com.example;

import lombok.Builder;

@Builder
public class Response{

    String errorCode;

    String Message;

    String status;

}